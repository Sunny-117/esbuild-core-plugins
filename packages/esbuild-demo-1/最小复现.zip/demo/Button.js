import './style.css';
export default function Button() {
  return 'button';
}
